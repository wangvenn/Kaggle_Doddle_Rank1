#if 3 channels, then 1/3 image, 2/3 image, full image
#chinese: 每个channel一张灰度图，如果共3channels, 那第一个显示前1/3笔画
#example: m1-1, m1-2, m1-3
def drawing_to_image_with_greyscale_multi_channel(drawing, H, W, seq, channels):
    cts = int(channels)

    point=[]
    time =[]
    for t,(x,y) in enumerate(drawing):
        point.append(np.array((x,y),np.float32).T)
        time.append(np.full(len(x),t))

    point = np.concatenate(point).astype(np.float32)
    time  = np.concatenate(time ).astype(np.int32)
    T = time.max()+1
    image_all = np.full((H,W,1),0,np.uint8)

    for ct in range(cts):
        image_tmp = np.full((H,W,1),0,np.uint8)
        x_max = point[:,0].max()
        x_min = point[:,0].min()
        y_max = point[:,1].max()
        y_min = point[:,1].min()
        w = x_max-x_min
        h = y_max-y_min
        #print(w,h)

        s = max(w,h)
        norm_point = (point-[x_min,y_min])/s
        norm_point = (norm_point-[w/s*0.5,h/s*0.5])*max(W,H)*0.85
        norm_point = np.floor(norm_point + [W/2,H/2]).astype(np.int32)

        P_part = 0
        for t in range(int((ct+1)*T/cts)):
            P_part += len(norm_point[time==t])
        if P_part > 0:
            #use grey color
            colors = plt.cm.gray(np.arange(0,P_part+1)/(P_part))
            colors = (colors[:,0]*255).astype(np.uint8)

        p_num = 0
        for t in range(int((ct+1)*T/cts)):
            p = norm_point[time==t]
            x,y = p.T
            image_tmp[y,x]=255
            N = len(p)
            for i in range(N-1):
                #only 1-D color is used for one channel
                color = colors[p_num]
                x0,y0 = p[i]
                x1,y1 = p[i+1]
                cv2.line(image_tmp,(x0,y0),(x1,y1),int(color),1,cv2.LINE_AA)
                p_num += 1

        if ct == 0:
            image_all = image_tmp
        else:
            image_all = np.concatenate((image_all,image_tmp),axis=2)

    image_all = seq.augment_image(image_all)
    return image_all

#encode by time, when pause > pause_time, change the color
#chinese: 按照设定的pause_time的阈值 如果两个点的间隔时间超过阈值，那么下一笔会变颜色
#example: m2, pause_time = 1000
def drawing_to_image_color_by_pause_time(drawing, H, W, pause_time, seq):
    
    point=[]
    stroke = []
    time =[]
    for s,(x,y,t) in enumerate(drawing):
        point.append(np.array((x,y),np.float32).T)
        stroke.append(np.full(len(x),s))
        time.append(np.full(len(x),t))

    point = np.concatenate(point).astype(np.float32)
    stroke  = np.concatenate(stroke).astype(np.int32)
    time  = np.concatenate(time).astype(np.int32)
    
    time_delta = []
    pause_times = 0
    for i in range(1,len(time)):
        delta = time[i] - time[i-1]
        time_delta.append(delta)
        if delta > pause_time:
            pause_times += 1
            
    image  = np.full((H,W,3),0,np.uint8)
    x_max = point[:,0].max()
    x_min = point[:,0].min()
    y_max = point[:,1].max()
    y_min = point[:,1].min()
    w = x_max-x_min
    h = y_max-y_min

    s = max(w,h)
    norm_point = (point-[x_min,y_min])/s
    norm_point = (norm_point-[w/s*0.5,h/s*0.5])*max(W,H)*0.85
    norm_point = np.floor(norm_point + [W/2,H/2]).astype(np.int32)

    T = stroke.max()+1
    
    colors = plt.cm.jet(np.arange(1,1+pause_times + 1)/(pause_times + 1))
    colors = (colors[:,:3]*255).astype(np.uint8)
    
    
    p_num = 0
    pause_count = 0
    for t in range(T):
        p = norm_point[stroke==t]
        x,y = p.T
        image[y,x]=255
        N = len(p)
        for i in range(N-1):
            if time_delta[p_num] > pause_time:
                pause_count += 1
            #current time - last time > pause threshold，then next stroke will change the color
            color = colors[pause_count]
            color = [int(color[2]),int(color[1]),int(color[0])]

            x0,y0 = p[i]
            x1,y1 = p[i+1]
            cv2.line(image,(x0,y0),(x1,y1),color,1,cv2.LINE_AA)
            p_num += 1
    image = seq.augment_image(image)
    return image


#divide time into M parts, M = the number of strokes. In each time part, color is same
#chinese: 按画图总时间，把时间分为M等分，M为笔画数量，每个时间间隔内，颜色一致
#example: m3
def drawing_to_image_by_time(drawing, H, W, seq):
    
    point=[]
    stroke = []
    time =[]
    for s,(x,y,t) in enumerate(drawing):
        point.append(np.array((x,y),np.float32).T)
        stroke.append(np.full(len(x),s))
        time.append(np.full(len(x),t))

    point = np.concatenate(point).astype(np.float32)
    stroke  = np.concatenate(stroke).astype(np.int32)
    time  = np.concatenate(time).astype(np.int32)

    image  = np.full((H,W,3),0,np.uint8)
    x_max = point[:,0].max()
    x_min = point[:,0].min()
    y_max = point[:,1].max()
    y_min = point[:,1].min()
    w = x_max-x_min
    h = y_max-y_min

    s = max(w,h)
    norm_point = (point-[x_min,y_min])/s
    norm_point = (norm_point-[w/s*0.5,h/s*0.5])*max(W,H)*0.85
    norm_point = np.floor(norm_point + [W/2,H/2]).astype(np.int32)

    T = stroke.max()+1
    colors = plt.cm.jet(np.arange(1,2+T)/(T+1))
    colors = (colors[:,:3]*255).astype(np.uint8)

    p_num = 0
    for t in range(T):
        p = norm_point[stroke==t]
        x,y = p.T
        image[y,x]=255
        N = len(p)
        for i in range(N-1):
            time_acc = time[p_num]
            color_num = int(time_acc*T/time[-1])
            color = colors[color_num]
            color = [int(color[2]),int(color[1]),int(color[0])]
            x0,y0 = p[i]
            x1,y1 = p[i+1]
            cv2.line(image,(x0,y0),(x1,y1),color,1,cv2.LINE_AA)
            p_num += 1
    
    image = seq.augment_image(image)
    return image


#each 3 channels has their RGB colors, can input 3,6,9... each point has its own color
#chinese: RGB图，颜色渐变
#example: m4
def drawing_to_image_with_color_point_multi_channel(drawing, H, W, seq, channels):
    cts = int(channels/3)

    point=[]
    time =[]
    for t,(x,y) in enumerate(drawing):
        point.append(np.array((x,y),np.float32).T)
        time.append(np.full(len(x),t))

    point = np.concatenate(point).astype(np.float32)
    time  = np.concatenate(time ).astype(np.int32)
    T = time.max()+1
    image_all = np.full((H,W,3),0,np.uint8)

    for ct in range(cts):
        image_tmp = np.full((H,W,3),0,np.uint8)
        x_max = point[:,0].max()
        x_min = point[:,0].min()
        y_max = point[:,1].max()
        y_min = point[:,1].min()
        w = x_max-x_min
        h = y_max-y_min
        #print(w,h)

        s = max(w,h)
        norm_point = (point-[x_min,y_min])/s
        norm_point = (norm_point-[w/s*0.5,h/s*0.5])*max(W,H)*0.85
        norm_point = np.floor(norm_point + [W/2,H/2]).astype(np.int32)

        #produce colors
        P_part = 0
        for t in range(int(ct*T/cts), int((ct+1)*T/cts)):
            P_part += len(norm_point[time==t])
        if P_part > 0:
            colors = plt.cm.jet(np.arange(0,P_part+1)/(P_part))
            colors = (colors[:,:3]*255).astype(np.uint8)
        #draw
        p_num = 0
        for t in range(int(ct*T/cts), int((ct+1)*T/cts)):
            p = norm_point[time==t]
            x,y = p.T
            image_tmp[y,x]=255
            N = len(p)
            for i in range(N-1):
                color = colors[p_num]
                color = [int(color[2]),int(color[1]),int(color[0])]
                x0,y0 = p[i]
                x1,y1 = p[i+1]
                cv2.line(image_tmp,(x0,y0),(x1,y1),color,1,cv2.LINE_AA)
                p_num += 1

        if ct == 0:
            image_all = image_tmp
        else:
            image_all = np.concatenate((image_all,image_tmp),axis=2)

    image_all = seq.augment_image(image_all)
    return image_all

#each 3 channels has their RGB colors, can input 3,6,9... same stroke has same color
#chinese: RGB图，颜色随笔画改变
#example: m5
def drawing_to_image_with_color_stroke_multi_channel(drawing, H, W, seq, channels):
    cts = int(channels/3)

    point=[]
    time =[]
    for t,(x,y) in enumerate(drawing):
        point.append(np.array((x,y),np.float32).T)
        time.append(np.full(len(x),t))

    point = np.concatenate(point).astype(np.float32)
    time  = np.concatenate(time ).astype(np.int32)
    T = time.max()+1
    image_all = np.full((H,W,3),0,np.uint8)

    colors = plt.cm.jet(np.arange(1,1+T)/(T))
    colors = (colors[:,:3]*255).astype(np.uint8)

    for ct in range(cts):
        image_tmp = np.full((H,W,3),0,np.uint8)
        x_max = point[:,0].max()
        x_min = point[:,0].min()
        y_max = point[:,1].max()
        y_min = point[:,1].min()
        w = x_max-x_min
        h = y_max-y_min
        #print(w,h)

        s = max(w,h)
        norm_point = (point-[x_min,y_min])/s
        norm_point = (norm_point-[w/s*0.5,h/s*0.5])*max(W,H)*0.85
        norm_point = np.floor(norm_point + [W/2,H/2]).astype(np.int32)

        #draw
        for t in range(int(ct*T/cts), int((ct+1)*T/cts)):

            color = colors[t]
            color = [int(color[2]),int(color[1]),int(color[0])]
            
            p = norm_point[time==t]
            x,y = p.T
            image_tmp[y,x]=255
            N = len(p)
            for i in range(N-1):
                x0,y0 = p[i]
                x1,y1 = p[i+1]
                cv2.line(image_tmp,(x0,y0),(x1,y1),color,1,cv2.LINE_AA)

        if ct == 0:
            image_all = image_tmp
        else:
            image_all = np.concatenate((image_all,image_tmp),axis=2)
    
    image_all = seq.augment_image(image_all)

    return image_all